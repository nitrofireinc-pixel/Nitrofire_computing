#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-or-later WITH AdditionRef-RGBMatrixFX-plugin-exception
# SPDX-FileCopyrightText: © 2026 Nitrofire Computing
"""Unit tests (stdlib unittest): python3 -m unittest discover -s tests -v"""
import math, os, sys, tempfile, threading, time, unittest
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from rgbmatrixfx import config, ipc, layout as L
from rgbmatrixfx.effects import EFFECTS, EFFECT_BY_ID
from rgbmatrixfx.scene import Scene, Compositor

MAMBA = L.MOUSE_PROFILES[0x0073]


def prof(effect="static", params=None, **kw):
    p = config.make_profile(effect, params or {}, reactive=kw.pop("reactive", {"enabled": False}))
    p["highlights"] = kw.pop("highlights", [])
    return config.sanitize_profile(p)


class TestLayout(unittest.TestCase):
    def test_keys_unique_cells(self):
        cells = [(k.row, k.col) for k in L.KEYS]
        self.assertEqual(len(cells), len(set(cells)))
        self.assertEqual(L.KEY_BY_NAME["LOGO"].row, 0)
        self.assertEqual(L.KEY_BY_NAME["LOGO"].col, 20)
        lg, ralt, fn = L.KEY_BY_NAME["LOGO"], L.KEY_BY_NAME["RIGHTALT"], L.KEY_BY_NAME["FN"]
        self.assertAlmostEqual(lg.cx, ralt.x + ralt.w, places=6)        # below the RAlt|Fn gap
        self.assertGreater(lg.y, L.KB_H)                                 # on the bottom frame edge
        self.assertLessEqual(lg.y + lg.h, L.KB_H + L.KB_LIP)
        self.assertGreater(lg.cx, L.KB_W / 2 - 0.01)                     # just right of centre
        sc = Scene(MAMBA)
        i = sc.cell_index(0, 20)
        self.assertAlmostEqual(sc.y[i], lg.cy, places=6)                # engine uses the same point

    def test_keycodes(self):
        self.assertEqual(L.KEYCODE_TO_CELL[17], (2, 3))     # KEY_W (Cynosa matrix is staggered)
        self.assertEqual(L.KEYCODE_TO_CELL[30], (3, 2))     # KEY_A
        self.assertEqual(L.KEYCODE_TO_CELL[1], (0, 1))      # KEY_ESC

    def test_mamba_profile(self):
        for pid in (0x0072, 0x0073):
            self.assertEqual(L.MOUSE_PROFILES[pid]["leds"], {"scroll": [0], "logo": [1]})
        self.assertNotIn("mouse_sides", L.ZONES)


class TestEffects(unittest.TestCase):
    def test_all_effects_all_choices(self):
        sc = Scene(MAMBA)
        self.assertGreaterEqual(len(EFFECTS), 8)
        for cls in EFFECTS:
            variants = [{}]
            for s in cls.schema():
                if s["type"] == "choice":
                    variants += [{s["id"]: c} for c in s["choices"]]
            for v in variants:
                fx = cls(sc, v, seed=1)
                t = 0.0
                for i in range(40):
                    if i % 7 == 0:
                        fx.on_press(sc.x[30], sc.y[30], 30, t)
                    out = fx.step(t, 1 / 30)
                    t += 1 / 30
                self.assertEqual(out.shape, (sc.n, 3), cls.id)
                self.assertTrue(np.isfinite(out).all(), (cls.id, v))
                self.assertGreaterEqual(out.min(), -1e-6, (cls.id, v))
                self.assertLessEqual(out.max(), 1 + 1e-6, (cls.id, v))

    def test_every_param_extreme_values(self):
        """every tunable (incl. Advanced) at its min and max renders sane output"""
        sc = Scene(MAMBA)
        for cls in EFFECTS:
            for spec in cls.schema():
                if spec["type"] not in ("float", "int"):
                    continue
                for v in (spec["min"], spec["max"]):
                    fx = cls(sc, {spec["id"]: v}, seed=2)
                    t = 0.0
                    for i in range(12):
                        if i % 4 == 0:
                            fx.on_press(sc.x[40], sc.y[40], 40, t)
                        out = fx.step(t, 1 / 30)
                        t += 1 / 30
                    self.assertTrue(np.isfinite(out).all(), (cls.id, spec["id"], v))

    def test_advanced_params_change_output(self):
        """advanced params are really wired in (changing one alters the frames)"""
        sc = Scene(MAMBA)
        dead = []
        for cls in EFFECTS:
            for spec in cls.schema():
                if not spec.get("adv") or spec["type"] not in ("float", "int", "bool", "choice"):
                    continue
                if (cls.id, spec["id"]) == ("audio", "range"):
                    continue        # only applies to live audio capture (no audio source in tests)
                if spec["type"] == "bool":
                    alt = not spec["default"]
                elif spec["type"] == "choice":
                    alt = [c for c in spec["choices"] if c != spec["default"]][0]
                else:
                    alt = spec["max"] if spec["default"] != spec["max"] else spec["min"]
                    if spec["id"] == "max":
                        alt = spec["min"]       # cap below the number of live ripples
                extra = {"length": "Custom"} if spec["id"] == "custom_time" else {}
                extra.update({"mode": "Dual"} if spec["id"] == "dual_mix" else {})
                extra.update({"mode": "Random", "random": True} if spec["id"] == "rand_sat" else {})
                extra.update({"style": "Plasma"} if spec["id"] in ("pcx", "pcy", "pshift") else {})
                extra.update({"direction": "Center out"} if cls.id == "wave" and spec["id"] in ("cx", "cy") else {})
                frames = []
                for val in (spec["default"], alt):
                    fx = cls(sc, dict(extra, **{spec["id"]: val}), seed=3)
                    acc, t = [], 0.0
                    for i in range(90):
                        if i % 6 == 0:
                            for kk in (40, 41, sc.n_kb - 3):
                                fx.on_press(sc.x[kk], sc.y[kk], kk, t)
                        if i % 10 == 0 and fx.reactive_hint:
                            fx.on_press(*L.MOUSE_BUTTON_POS[272], None, t)
                        acc.append(fx.step(t, 1 / 30))
                        t += 1 / 30
                    frames.append(np.array(acc))
                if np.allclose(frames[0], frames[1]):
                    dead.append("%s.%s" % (cls.id, spec["id"]))
        self.assertEqual(dead, [])

    def test_brightness_zero_is_black(self):
        sc = Scene(MAMBA)
        for cls in EFFECTS:
            fx = cls(sc, {"brightness": 0.0}, seed=1)
            self.assertAlmostEqual(float(np.clip(fx.step(1.0, 0.03), 0, 1).max()), 0.0, places=6, msg=cls.id)

    def test_sound_bars_default_bands_are_not_silent(self):
        """the default 16 bars each get at least one FFT bin (they used to stay at zero)"""
        from rgbmatrixfx.effects import band_levels, AudioMeter
        for n, nb in ((1024, 16), (1024, 4), (1024, 22), (32, 16), (16, 16), (8, 4)):
            bands = band_levels(np.ones(n), nb)
            self.assertEqual(bands.shape, (nb,), (n, nb))
            self.assertTrue(np.allclose(bands, 1.0), (n, nb, bands))
        self.assertTrue(np.all(band_levels(np.ones(3), 16) == 0))
        sc = Scene(MAMBA)
        fx = AudioMeter(sc, {"bands": 16, "demo": False}, seed=1)
        t = np.linspace(0, 1, 2048, endpoint=False)
        tone = np.sin(2 * np.pi * 80 * t) + 0.4 * np.sin(2 * np.pi * 800 * t)

        class _Src:
            alive = True
            def samples(_s):
                return tone

        fx.source = _Src()
        out = fx.step(0.05, 1 / 30)
        self.assertGreater(float(out.max()), 0.05)
        self.assertEqual(fx.levels.shape, (16,))
        self.assertGreater(float(fx.levels.max()), 0.0)

    def test_wave_moves_onto_mouse(self):
        sc = Scene(MAMBA)
        fx = EFFECT_BY_ID["wave"](sc, {"direction": "Left → Right"})
        a = fx.step(0.0, 0.0)[sc.mouse_points["logo"][0]].copy()
        b = fx.step(0.5, 0.5)[sc.mouse_points["logo"][0]]
        self.assertFalse(np.allclose(a, b))


class TestCompositor(unittest.TestCase):
    def setUp(self):
        self.sc = Scene(MAMBA)

    def test_highlight_on_top_of_ripple(self):
        p = prof("static", {"color": "#000000"}, reactive={"enabled": True, "color": "#00ff00"},
                 highlights=[{"name": "WASD", "keys": ["W", "A", "S", "D"], "color": "#ffffff", "on_top": True}])
        c = Compositor(self.sc, p, {"master_brightness": 1.0})
        c.press_key(17, 0.0)
        rgb = c.render(0.02)
        w = self.sc.cell_index(2, 3)
        np.testing.assert_allclose(rgb[w], [1, 1, 1])
        e = self.sc.cell_index(2, 4)
        self.assertGreater(rgb[e][1], 0.3)          # ripple visible next to W

    def test_ripple_reaches_mouse_with_distance_delay(self):
        speed = 20.0
        p = prof("static", {"color": "#000000"},
                 reactive={"enabled": True, "color": "#ffffff", "speed": speed, "life": 3.0, "width": 0.9})
        c = Compositor(self.sc, p, {})
        c.press_key(17, 0.0)
        scroll = self.sc.mouse_points["scroll"][0]
        lit = None
        t = 0.0
        while t < 3.0:
            t += 1 / 60
            if c.render(t)[scroll].sum() > 0.5:
                lit = t
                break
        w = L.KEY_BY_NAME["W"]
        d = math.hypot(w.cx - self.sc.x[scroll], w.cy - self.sc.y[scroll])
        self.assertIsNotNone(lit)
        self.assertAlmostEqual(lit, d / speed, delta=0.12)

    def test_mouse_click_ripple(self):
        p = prof("static", {"color": "#000000"}, reactive={"enabled": True, "color": "#ff0000"})
        c = Compositor(self.sc, p, {})
        self.assertTrue(c.press_mouse(272, 0.0))
        rgb = c.render(0.03)
        self.assertGreater(rgb[self.sc.mouse_points["scroll"][0]][0], 0.3)
        self.assertTrue(c.wheel(0.1))
        self.assertFalse(c.wheel(0.15))             # rate limit

    def test_trigger_toggles(self):
        p = prof("static", {"color": "#000000"}, reactive={"enabled": True, "keyboard": False, "mouse_buttons": False})
        c = Compositor(self.sc, p, {})
        self.assertFalse(c.press_key(17, 0))
        self.assertFalse(c.press_mouse(272, 0))

    def test_independent_zones_and_frames(self):
        p = prof("static", {"color": "#ff0000"})
        p["zones"]["mouse_logo"].update(mode="static", color="#0000ff")
        p["zones"]["mouse_scroll"].update(mode="off")
        p["zones"]["kb_logo"].update(mode="static", color="#00ff00", brightness=0.5)
        c = Compositor(self.sc, p, {"master_brightness": 1.0})
        rgb = c.render(0.0)
        mf = c.mouse_frame(rgb, 1, 16)
        self.assertEqual(tuple(mf[0, 0]), (0, 0, 0))          # col 0 = scroll (off)
        self.assertEqual(tuple(mf[0, 1]), (0, 0, 255))        # col 1 = logo
        self.assertTrue((mf[0, 2:] == 0).all())                # nothing else
        kf = c.kb_frame(rgb, 6, 22)
        self.assertEqual(tuple(kf[0, 20]), (0, 128, 0))
        self.assertEqual(tuple(kf[2, 2]), (255, 0, 0))
        self.assertEqual(c.mouse_zone_colors(rgb), {"logo": (0, 0, 255), "scroll": (0, 0, 0)})

    def test_zone_not_reactive(self):
        p = prof("static", {"color": "#000000"}, reactive={"enabled": True, "color": "#ffffff"})
        p["zones"]["mouse_logo"].update(mode="static", color="#000000", reactive=False)
        c = Compositor(self.sc, p, {})
        c.press_mouse(272, 0.0)
        for i in range(30):
            rgb = c.render(i / 30)
            self.assertEqual(rgb[self.sc.mouse_points["logo"][0]].sum(), 0)

    def test_master_brightness_and_identify(self):
        c = Compositor(self.sc, prof("static", {"color": "#ffffff"}), {"master_brightness": 0.25})
        self.assertAlmostEqual(float(c.render(0)[5][0]), 0.25)
        c.set_global({"master_brightness": 1.0})
        c.start_identify("mouse_logo", 0.0)
        i = self.sc.mouse_points["logo"][0]
        a = c.render(0.05)[i].sum()
        b = c.render(0.25)[i].sum()
        self.assertNotEqual(a, b)

    def test_generic_mouse_all_columns(self):
        sc = Scene(L.GENERIC_MOUSE)
        c = Compositor(sc, prof("static", {"color": "#123456"}), {})
        mf = c.mouse_frame(c.render(0), 1, 16)
        self.assertTrue((mf == np.array([0x12, 0x34, 0x56])).all())
        self.assertFalse(sc.zone_present["mouse_scroll"])


class TestMouseGeometry(unittest.TestCase):
    def tearDown(self):
        L.set_mouse_position(2.0, 0.0)

    def test_gap_changes_ripple_delay(self):
        delays = []
        for gap in (2.0, 8.0):
            L.set_mouse_position(gap, 0.0)
            sc = Scene(MAMBA)
            c = Compositor(sc, prof("static", {"color": "#000000"},
                                    reactive={"enabled": True, "speed": 20.0, "life": 4.0}), {})
            c.press_key(17, 0.0)
            i, t = sc.mouse_points["scroll"][0], 0.0
            while t < 4 and c.render(t)[i].sum() < 0.5:
                t += 1 / 60
            delays.append(t)
        self.assertAlmostEqual(delays[1] - delays[0], 6.0 / 20.0, delta=0.06)

    def test_reactive_advanced(self):
        sc = Scene(MAMBA)
        c = Compositor(sc, prof("static", {"color": "#000000"},
                                reactive={"enabled": True, "wheel_interval": 0.5}), {})
        self.assertTrue(c.wheel(0.0))
        self.assertFalse(c.wheel(0.3))
        self.assertTrue(c.wheel(0.6))
        lo = Compositor(sc, prof("static", {"color": "#000000"}, reactive={"enabled": True, "gain": 0.3}), {})
        hi = Compositor(sc, prof("static", {"color": "#000000"}, reactive={"enabled": True, "gain": 3.0}), {})
        for cc in (lo, hi):
            cc.press_key(30, 0.0)
        self.assertLess(lo.render(0.1).sum(), hi.render(0.1).sum())


class TestConfig(unittest.TestCase):
    def test_default_is_flame_with_mouse(self):
        cfg = config.default_config()
        self.assertEqual(cfg["global"]["active_preset"], "Flame")
        self.assertEqual(cfg["profile"]["effect"], "flame")
        self.assertTrue(cfg["global"]["include_mouse"])
        self.assertEqual(cfg["profile"]["highlights"][0]["keys"], ["W", "A", "S", "D"])
        self.assertTrue(cfg["profile"]["reactive"]["enabled"])
        self.assertGreaterEqual(len(cfg["presets"]), 8)

    def test_sanitize_garbage(self):
        bad = {"global": {"fps": 9999, "master_brightness": "x", "exit_mode": "boom"},
               "profile": {"effect": "nope", "reactive": {"speed": -5}, "zones": {"mouse_sides": {"mode": "static"}},
                           "highlights": [{"keys": ["W", "NOTAKEY"]}], "effects": {"wave": {"direction": "Sideways", "speed": 99}}}}
        cfg = config.sanitize_config(bad)
        self.assertLessEqual(cfg["global"]["fps"], 60)
        self.assertIn(cfg["global"]["exit_mode"], ("restore", "off", "leave"))
        self.assertEqual(cfg["profile"]["effect"], "flame")
        self.assertGreaterEqual(cfg["profile"]["reactive"]["speed"], 3)
        self.assertNotIn("mouse_sides", cfg["profile"]["zones"])
        self.assertEqual(cfg["profile"]["highlights"][0]["keys"], ["W"])
        self.assertEqual(config.sanitize_config(cfg), cfg)     # idempotent
        self.assertEqual(config.sanitize_config("junk")["profile"]["effect"], "flame")

    def test_save_load_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "sub", "config.json")
            cfg = config.default_config()
            cfg["profile"]["effect"] = "aurora"
            config.save(cfg, path)
            self.assertEqual(config.load(path)["profile"]["effect"], "aurora")
            with open(path, "w") as f:
                f.write("{broken")
            self.assertEqual(config.load(path)["profile"]["effect"], "flame")

    def test_presets_valid(self):
        for name, p in config.builtin_presets().items():
            self.assertEqual(config.sanitize_profile(p)["effect"], p["effect"], name)
        self.assertEqual(config.builtin_presets()["Deep Breath"]["effect"], "breathing")
        self.assertNotIn("Razer Breathing", config.builtin_presets())

    def test_legacy_preset_names_still_load(self):
        """a config saved under an older preset name still round-trips; the effect id is what matters"""
        cfg = config.default_config()
        cfg["presets"]["Razer Breathing"] = config.make_profile("breathing", {"color": "#44d62c"}, {"enabled": False})
        cfg["presets"]["Razer Fire"] = config.make_profile("fire", {}, {"color": "#ffffff", "mode": "fade"})
        cfg["global"]["active_preset"] = "Razer Breathing"
        got = config.sanitize_config(cfg)
        self.assertEqual(got["global"]["active_preset"], "Razer Breathing")
        self.assertEqual(got["presets"]["Razer Breathing"]["effect"], "breathing")
        self.assertEqual(got["presets"]["Razer Fire"]["effect"], "fire")
        self.assertEqual(got["presets"]["Deep Breath"]["effect"], "breathing")

    def test_effect_display_names_are_ours(self):
        from rgbmatrixfx.effects import EFFECTS
        banned = ("Razer Breathing", "Razer Wave", "Razer Spectrum", "Razer Starlight", "Razer Fire",
                  "Razer Reactive", "Razer Ripple", "Razer Wheel", "Razer Static", "Razer Audio")
        by_id = {c.id: c for c in EFFECTS}
        self.assertEqual(by_id["breathing"].name, "Deep Breath")
        self.assertEqual(by_id["breathing"].id, "breathing")
        for c in EFFECTS:
            blob = "%s %s %s" % (c.name, c.mimics, c.description)
            for phrase in banned:
                self.assertNotIn(phrase, blob, c.id)


class TestIPC(unittest.TestCase):
    def test_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "engine.sock")
            srv = ipc.Server(lambda req: {"ok": True, "echo": req}, path)
            stop = threading.Event()

            def loop():
                import select
                while not stop.is_set():
                    for fd in select.select(srv.fds(), [], [], 0.05)[0]:
                        srv.handle(fd)
            th = threading.Thread(target=loop, daemon=True)
            th.start()
            self.assertEqual(os.stat(path).st_mode & 0o777, 0o600)
            cl = ipc.Client(path, timeout=2)
            r = cl.call("ping", x=1)
            self.assertEqual(r["echo"], {"cmd": "ping", "x": 1})
            big = cl.call("frame", data="ab" * 50000)
            self.assertEqual(len(big["echo"]["data"]), 100000)
            stop.set(); th.join(1); srv.close()
            self.assertFalse(os.path.exists(path))
            cl.close()
            with self.assertRaises(OSError):
                ipc.Client(path, timeout=0.5).call("ping")


class FakeOut:
    def __init__(self, kind, rows, cols, pid):
        self.kind, self.rows, self.cols, self.pid = kind, rows, cols, pid
        self.frames = []


class FakeHub:
    """stands in for DeviceHub: records pushed frames"""
    def __init__(self):
        self.kb = FakeOut("keyboard", 6, 22, 0x022A)
        self.mouse = FakeOut("mouse", 1, 16, 0x0073)
        self.any = True
        self.finished = None
        self.scans = 0
        self.extras = []

    def keymap(self):
        from rgbmatrixfx import devmaps
        return devmaps.default_keymap()

    def extra_dims(self):
        return []

    def maybe_scan(self, now, want_mouse=True):
        self.scans += 1
        return self.scans == 1

    def mouse_profile(self):
        return MAMBA

    def configure(self, g):
        self.cfg_g = dict(g)

    def push(self, kb, mf, zones, now, method, extra_frames=()):
        self.kb.frames.append(kb)
        self.mouse.frames.append(mf)

    def finish(self, mode):
        self.finished = mode

    def info(self):
        return {"state": "ok", "keyboard": None, "mouse": None}


class FakeInputs:
    def __init__(self):
        self.devs = {}
        self.enable_mouse = True

    def fds(self): return []
    def scan(self): pass
    def info(self): return {"evdev": True, "nodes": []}
    def close(self): pass


class _FakeLighting:
    def __init__(self, delay=0.0):
        self.calls = []
        self.delay = delay

    def setKeyRow(self, payload):
        time.sleep(self.delay)
        self.calls.append(("row", bytes(payload)))

    def setCustom(self):
        self.calls.append(("custom",))


class _FakeDev:
    def __init__(self, rows, cols, pid, delay=0.0, serial="XX123"):
        import types
        self._pid, self.name, self.serial, self.type = pid, "Fake", serial, "keyboard"
        self.light = _FakeLighting(delay)
        self.fx = types.SimpleNamespace(advanced=types.SimpleNamespace(rows=rows, cols=cols, _lighting_dbus=self.light))


class TestGamerControls(unittest.TestCase):
    def _idx(self, sc, name):
        k = L.KEY_BY_NAME[name]
        return sc.cell_index(k.row, k.col)

    def test_overrides_effect_reactive_and_highlights(self):
        sc = Scene(MAMBA)
        prof = config.make_profile("spectrum", reactive={"enabled": True, "mode": "both", "color": "#ff0000"})
        prof["highlights"] = [{"name": "red", "keys": ["W", "A"], "color": "#ff0000", "on_top": True, "enabled": True}]
        prof["zones"]["keyboard"]["brightness"] = 0.4
        g = dict(config.DEFAULT_GLOBAL, gamer_controls=True)
        comp = Compositor(sc, prof, g, seed=1)
        comp.press_key(L.KEY_BY_NAME["S"].codes[0], 0.0)    # ripple + fade right on S
        for t in (0.02, 0.05, 0.3, 1.0):
            rgb = comp.render(t)
            for k in L.WASD:
                self.assertTrue(np.allclose(rgb[self._idx(sc, k)], 1.0), (k, t, rgb[self._idx(sc, k)]))
        self.assertFalse(np.allclose(rgb[self._idx(sc, "G")], 1.0))
        comp.set_global(dict(g, gamer_controls=False))
        rgb = comp.render(1.1)
        self.assertTrue(np.allclose(rgb[self._idx(sc, "W")], (0.4, 0, 0)))  # own highlight again, zone-dimmed

    def test_custom_keys_colour_and_every_preset(self):
        sc = Scene(MAMBA)
        g = config.sanitize_config({"global": {"gamer_controls": True, "gamer_keys": ["up", "LEFT", "bogus", "UP"],
                                               "gamer_color": "#00FF00"}})["global"]
        self.assertEqual(g["gamer_keys"], ["UP", "LEFT"])
        self.assertEqual(g["gamer_color"], "#00ff00")
        for name, prof in config.builtin_presets().items():
            comp = Compositor(sc, prof, g, seed=2)
            rgb = comp.render(0.5)
            self.assertTrue(np.allclose(rgb[self._idx(sc, "UP")], (0, 1, 0)), name)
            self.assertTrue(np.allclose(rgb[self._idx(sc, "LEFT")], (0, 1, 0)), name)

    def test_defaults_and_persistence(self):
        c = config.default_config()
        self.assertEqual((c["global"]["gamer_controls"], c["global"]["gamer_keys"], c["global"]["gamer_color"]),
                         (False, ["W", "A", "S", "D"], "#ffffff"))
        bad = config.sanitize_config({"global": {"gamer_keys": "WASD", "gamer_color": "white"}})["global"]
        self.assertEqual((bad["gamer_keys"], bad["gamer_color"]), (["W", "A", "S", "D"], "#ffffff"))
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "c.json")
            c["global"].update(gamer_controls=True, gamer_keys=["Q", "E"])
            config.save(c, p)
            g = config.load(p)["global"]
            self.assertEqual((g["gamer_controls"], g["gamer_keys"]), (True, ["Q", "E"]))


class TestFullFrames(unittest.TestCase):
    def test_full_frames_default_sends_every_row(self):
        from rgbmatrixfx import devices
        if True:
            out = devices.Out.__new__(devices.Out)
            out.rows, out.cols, out.sent, out._next_full = 6, 22, None, 0.0
            out.opts = dict(devices.DEFAULT_IO); out._need_kick = False; out._next_kick = 1e9
            out.rows_sent = 0; sent = []; out.full_ms = []; out._count = lambda *a: None
            out._write_frame = lambda p: sent.append(len(p))
            out.kind = "keyboard"
            f = np.zeros((6, 22, 3), np.uint8)
            out._write_matrix(f, 100.0)
            f[2, 5] = 200
            out._write_matrix(f, 100.1)
            self.assertEqual(sent, [6 * 69, 6 * 69])

    def test_every_effect_writes_all_keyboard_rows(self):
        """every effect is sent as a full frame: all keyboard rows, every frame"""
        from rgbmatrixfx import devices
        sc = Scene(MAMBA)
        for cls in EFFECTS:
            comp = Compositor(sc, prof(cls.id), {"master_brightness": 1.0}, seed=1)
            out = devices.Out.__new__(devices.Out)
            out.rows, out.cols, out.sent, out._next_full = sc.kb_rows, sc.kb_cols, None, 0.0
            out.opts = dict(devices.DEFAULT_IO); out._need_kick = False; out._next_kick = 1e9
            out.rows_sent = 0; sent = []; out.full_ms = []; out._count = lambda *a: None
            out._write_frame = lambda p: sent.append(len(p))
            out.kind = "keyboard"
            row_bytes = 3 + sc.kb_cols * 3
            for i in range(4):
                rgb = comp.render(i / 30.0)
                self.assertEqual(rgb.shape, (sc.n, 3), cls.id)
                out._write_matrix(comp.kb_frame(rgb, sc.kb_rows, sc.kb_cols), 100.0 + i * 0.03)
            self.assertEqual(sent, [sc.kb_rows * row_bytes] * 4, cls.id)


class TestDeviceIO(unittest.TestCase):
    def _sysfs(self, d, pid=0x022A, serial="XX123"):
        dd = os.path.join(d, "razerkbd", "0003:1532:%04X.0006" % pid)
        os.makedirs(dd)
        for a in ("matrix_custom_frame", "matrix_effect_custom"):
            open(os.path.join(dd, a), "wb").close()
        with open(os.path.join(dd, "device_serial"), "w") as f:
            f.write(serial + "\n")
        return dd

    def test_sysfs_changed_rows_and_single_custom(self):
        from rgbmatrixfx import devices
        with tempfile.TemporaryDirectory() as d:
            dd = self._sysfs(d)
            os.environ["RGBMATRIXFX_SYSFS_ROOT"] = d
            try:
                dev = _FakeDev(6, 22, 0x022A)
                out = devices.Out(dev, "keyboard")
            finally:
                del os.environ["RGBMATRIXFX_SYSFS_ROOT"]
            self.assertEqual(out.path, "sysfs")
            self.assertEqual(out.sysfs, dd)
            def rd(a):
                with open(os.path.join(dd, a), "rb") as fh:
                    return fh.read()
            f = np.zeros((6, 22, 3), np.uint8)
            f[:, :] = 10
            out.opts["rolling_refresh"] = False
            out.opts["full_frames"] = False          # this test covers the partial-row path
            out._write_matrix(f, 100.0)
            self.assertEqual(len(rd("matrix_custom_frame")), 6 * (3 + 66))
            self.assertEqual(dev.light.calls, [("custom",)])        # first kick through the daemon
            f2 = f.copy(); f2[2, 5] = (200, 0, 0)
            out._write_matrix(f2, 100.1)
            b = rd("matrix_custom_frame")
            self.assertEqual((len(b), b[0], b[1], b[2]), (69, 2, 0, 21))
            self.assertEqual(tuple(b[3 + 15:3 + 18]), (200, 0, 0))
            out._write_matrix(f2.copy(), 100.15)                    # settle: row 2 resent once
            self.assertEqual(rd("matrix_custom_frame")[0], 2)
            n = out.frames
            out._write_matrix(f2.copy(), 100.2)                     # unchanged -> nothing sent
            f3 = f2.copy(); f3[4, 0] = (11, 10, 10)                 # within row_delta=1 -> skipped
            out._write_matrix(f3, 100.3)
            self.assertEqual(out.frames, n)
            self.assertEqual(dev.light.calls, [("custom",)])        # no per-frame setCustom
            f4 = f2.copy(); f4[1] = 0                               # going dark is always sent
            out._write_matrix(f4, 100.4)
            self.assertEqual(rd("matrix_custom_frame")[0], 1)
            open(os.path.join(dd, "matrix_effect_custom"), "wb").close()
            f5 = f4.copy(); f5[0, 0] = 99
            out._write_matrix(f5, 106.0)                            # full refresh + periodic re-kick via sysfs
            self.assertEqual(len(rd("matrix_custom_frame")), 6 * 69)
            self.assertEqual(rd("matrix_effect_custom"), b"1")
            self.assertEqual(out.kicks, 2)

    def test_dbus_fallback_and_custom_every_frame(self):
        from rgbmatrixfx import devices
        dev = _FakeDev(1, 16, 0x0073)
        out = devices.Out(dev, "mouse", opts={"device_io": "dbus", "custom_every_frame": True})
        self.assertEqual(out.path, "dbus")
        f = np.zeros((1, 16, 3), np.uint8)
        out._write_matrix(f, 1.0)
        f[0, 1] = 50
        out._write_matrix(f, 1.1)
        self.assertEqual([c[0] for c in dev.light.calls], ["row", "custom", "row", "custom"])
        self.assertEqual(len(dev.light.calls[0][1]), 3 + 48)

    def test_writer_thread_never_blocks_and_keeps_latest(self):
        from rgbmatrixfx import devices
        dev = _FakeDev(1, 16, 0x0073, delay=0.06)
        out = devices.Out(dev, "mouse", opts={"device_io": "dbus", "mouse_max_fps": 60}).start()
        try:
            t = time.monotonic()
            for i in range(20):
                f = np.zeros((1, 16, 3), np.uint8); f[0, 0] = i * 10
                out.submit("matrix", f)
                time.sleep(0.005)
            self.assertLess(time.monotonic() - t, 0.5)
            for _ in range(100):
                if out.sent is not None and out.sent[0, 0, 0] == 190 and out._job is None:
                    break
                time.sleep(0.02)
            self.assertEqual(int(out.sent[0, 0, 0]), 190)
            rows = [c for c in dev.light.calls if c[0] == "row"]
            self.assertLess(len(rows), 10)                          # stale frames were dropped
        finally:
            out.stop()
        self.assertIsNone(out.error)

    def test_eviocsmask_codes_size_is_whole_longs(self):
        import struct
        from rgbmatrixfx import inputs
        seen = {}
        orig = inputs.fcntl.ioctl
        inputs.fcntl.ioctl = lambda fd, req, arg: seen.update(req=req, arg=arg)
        try:
            inputs.set_rel_mask(3)
        finally:
            inputs.fcntl.ioctl = orig
        typ, size, _ = struct.unpack("IIQ", seen["arg"])
        self.assertEqual((seen["req"], typ, size % 8), (0x40104593, 2, 0))


class TestAdaptiveFps(unittest.TestCase):
    def test_slow_keyboard_gets_an_even_lower_rate(self):
        from rgbmatrixfx import devices
        from rgbmatrixfx.engine import Engine
        class KB:
            full_ms = []
            write_ms = 36.0
            sustainable_fps = devices.Out.sustainable_fps
        kb = KB()
        self.assertIsNone(kb.sustainable_fps(30))                  # not enough data
        kb.full_ms = [35.7] * 80 + [38.2] * 10
        self.assertEqual(kb.sustainable_fps(30), 24)               # 36-38 ms writes -> 24 fps, every frame
        kb.full_ms = [12.0] * 90
        self.assertEqual(kb.sustainable_fps(30), 30)               # fast device: unchanged
        eng = Engine.__new__(Engine)
        eng.fps_out = None
        eng.hub = type("H", (), {"kb": kb})()
        g = {"fps": 30, "adaptive_fps": True}
        kb.full_ms = [36.0] * 90
        eng._adapt_fps(g)
        self.assertIsNone(eng.fps_out)                             # one slow reading isn't enough
        eng._adapt_fps(g)
        self.assertEqual(eng.fps_out, 24)
        for ms in [30.0, 38.0, 33.0, 40.0, 31.0, 37.0] * 3:       # load wobble: no flapping
            kb.full_ms = [ms] * 90
            eng._adapt_fps(g)
            self.assertEqual(eng.fps_out, 24)
        kb.full_ms = [12.0] * 90                                   # really faster: back up after ~12 s
        for _ in range(3):
            eng._adapt_fps(g)
        self.assertEqual(eng.fps_out, 24)
        eng._adapt_fps(g)
        self.assertIsNone(eng.fps_out)
        kb.full_ms = [38.2] * 90
        eng._adapt_fps(dict(g, adaptive_fps=False))
        self.assertIsNone(eng.fps_out)                             # opt-out keeps the configured rate


class TestEngine(unittest.TestCase):
    def test_dead_audio_capture_restarts_after_backoff(self):
        from rgbmatrixfx.engine import Engine

        class Dead:
            alive = False
            error = None
            def __init__(self):
                self.stops = 0
            def stop(self):
                self.stops += 1

        eng = Engine.__new__(Engine)
        eng.comp = type("C", (), {"effect_id": "audio"})()
        eng.cfg = {"global": {"paused": False}}
        dead = Dead()
        eng.audio = dead
        eng.clock = lambda: 10.0
        eng._audio_update()
        self.assertIsNone(eng.audio)
        self.assertEqual(dead.stops, 1)
        self.assertEqual(eng._audio_retry, 15.0)
        again = Dead()
        eng.audio = again
        eng.clock = lambda: 12.0          # inside the 5 s backoff
        eng._audio_update()
        self.assertIs(eng.audio, again)
        self.assertEqual(again.stops, 0)
        eng.clock = lambda: 15.0
        eng._audio_update()
        self.assertIsNone(eng.audio)
        self.assertEqual(again.stops, 1)

    def test_engine_loop_fake_hub(self):
        from rgbmatrixfx.engine import Engine
        with tempfile.TemporaryDirectory() as d:
            hub = FakeHub()
            eng = Engine(cfg_path=os.path.join(d, "c.json"), sock_path=os.path.join(d, "s"), hub=hub, inputs=FakeInputs())
            r = eng.handle({"cmd": "inject", "kind": "key", "code": 17})
            self.assertTrue(r["ok"])
            eng.run(duration=1.0)
            n = len(hub.kb.frames)
            self.assertTrue(25 <= n <= 33, n)
            self.assertEqual(hub.mouse.frames[-1].shape, (1, 16, 3))
            self.assertEqual(hub.kb.frames[-1].shape, (6, 22, 3))
            self.assertEqual(hub.finished, "restore")
            st = eng.handle({"cmd": "status"})["status"]
            self.assertEqual(st["mouse_pid"], 0x0073)
            self.assertFalse(eng.handle({"cmd": "bogus"})["ok"])

    def test_external_source_frames_and_fallback(self):
        import time as _t
        from rgbmatrixfx.engine import Engine
        from rgbmatrixfx import effects as fx
        with tempfile.TemporaryDirectory() as d:
            eng = Engine(cfg_path=os.path.join(d, "c.json"), sock_path=os.path.join(d, "s"), hub=FakeHub(), inputs=FakeInputs())
            sc = eng.handle({"cmd": "scene"})
            n = sc["n"]
            self.assertEqual((len(sc["x"]), len(sc["kind"]), sc["kb_rows"], sc["kb_cols"]), (n, n, 6, 22))
            prof = config.make_profile("external", {"source": "addon:test", "fallback": "static"})
            self.assertTrue(eng.handle({"cmd": "set_profile", "profile": prof})["ok"])
            self.assertEqual(eng.comp.effect_id, "external")
            self.assertEqual(eng.cfg["profile"]["effects"]["external"]["source"], "addon:test")
            st = eng.handle({"cmd": "status"})["status"]
            self.assertEqual(st["external"], {"source": "addon:test", "fallback": "static", "live": False, "settings": {}})
            static = eng.comp.render(_t.monotonic())          # no frames yet: the fallback plays
            self.assertGreater(static.max(), 0)
            self.assertFalse(eng.handle({"cmd": "source_frame", "source": "addon:test", "n": n - 1, "rgb": "00" * 3 * (n - 1)})["ok"])
            self.assertTrue(eng.handle({"cmd": "source_frame", "source": "addon:test", "n": n, "rgb": "ff0000" * n})["ok"])
            out = eng.comp.render(_t.monotonic())
            self.assertTrue(np.allclose(out[:, 0], 1.0) and np.allclose(out[:, 1:], 0.0))
            self.assertTrue(eng.handle({"cmd": "status"})["status"]["external"]["live"])
            fx.EXTERNAL_FRAMES["addon:test"] = (_t.monotonic() - 5, fx.EXTERNAL_FRAMES["addon:test"][1])
            self.assertFalse(np.allclose(eng.comp.render(_t.monotonic())[:, 1:], 0.0) and
                             np.allclose(eng.comp.render(_t.monotonic())[:, 0], 1.0))   # stale -> fallback
            fx.EXTERNAL_FRAMES.clear()
            fx.EXTERNAL_QUEUE.clear()
            # jitter buffer: two frames arriving in one tick, none in the next -> shown one per tick
            green, blue = "00ff00" * n, "0000ff" * n
            eng.handle({"cmd": "source_frame", "source": "addon:test", "n": n, "rgb": green})
            eng.handle({"cmd": "source_frame", "source": "addon:test", "n": n, "rgb": blue})
            a, b, c = (eng.comp.render(_t.monotonic()) for _ in range(3))
            self.assertTrue(a[0, 1] > 0.9 and b[0, 2] > 0.9 and c[0, 2] > 0.9)  # green, blue, hold blue
            for _ in range(10):
                eng.handle({"cmd": "source_frame", "source": "addon:test", "n": n, "rgb": green})
            self.assertLessEqual(len(fx.EXTERNAL_QUEUE["addon:test"]), fx.EXTERNAL_QUEUE_MAX)   # latency capped
            fx.EXTERNAL_FRAMES.clear()
            fx.EXTERNAL_QUEUE.clear()
            self.assertNotIn("external", [e.id for e in fx.EFFECTS])                     # not in the gallery



    def test_override_temporary_not_saved(self):
        from rgbmatrixfx.engine import Engine
        with tempfile.TemporaryDirectory() as d:
            cp = os.path.join(d, "c.json")
            eng = Engine(cfg_path=cp, sock_path=os.path.join(d, "s"), hub=FakeHub(), inputs=FakeInputs())
            base = eng.cfg["profile"]
            other = config.make_profile("static", {"color": "#0000ff"})
            r = eng.handle({"cmd": "set_override", "override": {"owner": "test", "label": "Game", "profile": other, "ttl": 5}})
            self.assertTrue(r["ok"] and r["override"]["profile"])
            self.assertEqual(eng.comp.effect_id, "static")
            self.assertEqual(eng.cfg["profile"], base)                    # the saved profile is untouched
            self.assertIsNone(eng.dirty_at)                               # and nothing is written to disk
            self.assertEqual(eng.handle({"cmd": "status"})["status"]["override"]["label"], "Game")
            # the first frames cross-fade from the previous picture (no black flash)
            eng.rgb = np.full((eng.scene.n, 3), 0.5)
            eng._xfade = (eng.rgb.copy(), 0.0)
            mid = eng._post(np.zeros((eng.scene.n, 3)), 0.125)
            self.assertTrue(np.allclose(mid, 0.25))
            # a GUI edit (set_config) keeps the override on screen
            eng.handle({"cmd": "set_global", "global": {"fps": 30}})
            self.assertEqual(eng.comp.effect_id, "static")
            # dim + warm tint eases in; off goes to black
            eng._xfade = None
            eng.handle({"cmd": "set_override", "override": {"owner": "test", "dim": 0.3, "tint": "#ffb070"}})
            self.assertNotEqual(eng.comp.effect_id, "static")             # no profile in the override: saved one again
            eng._xfade = None
            ones = np.ones((eng.scene.n, 3))
            for _ in range(60):
                out = eng._post(ones, 1.0)
            self.assertTrue(np.allclose(out[0], [0.3, 0.3 * 0xb0 / 255, 0.3 * 0x70 / 255], atol=0.01), (out[0], eng.override, eng._level))
            eng.handle({"cmd": "set_override", "override": {"owner": "test", "off": True}})
            for _ in range(60):
                out = eng._post(ones, 2.0)
            self.assertEqual(out.max(), 0.0)
            # expiry: not renewed -> back to normal by itself
            eng.override["until"] = 0
            eng.handle({"cmd": "set_override", "override": None})
            self.assertIsNone(eng.handle({"cmd": "status"})["status"].get("override"))
            for _ in range(60):
                out = eng._post(ones, 3.0)
            self.assertTrue(np.allclose(out, 1.0))


class TestGenericInputDetection(unittest.TestCase):
    def test_classify(self):
        from rgbmatrixfx.inputs import classify_generic
        b = "/dev/input/by-id/"
        paths = [b + n for n in (
            "usb-Razer_Razer_BlackWidow_V3-event-kbd", "usb-Razer_Razer_BlackWidow_V3-if01-event-kbd",
            "usb-Razer_Razer_BlackWidow_V3-if02-event-mouse",
            "usb-Razer_Razer_DeathAdder_V2-event-mouse", "usb-Razer_Razer_DeathAdder_V2-if01-event-kbd",
            "usb-Razer_Razer_Basilisk-if01-event-kbd", "usb-Razer_Razer_Basilisk-if02-event-mouse",
            "usb-Razer_Razer_Kraken-event-joystick", "usb-Logitech_USB_Receiver-event-mouse")]
        got = dict(classify_generic(paths))
        self.assertEqual(got[b + "usb-Razer_Razer_BlackWidow_V3-event-kbd"], "kb")
        self.assertEqual(got[b + "usb-Razer_Razer_BlackWidow_V3-if01-event-kbd"], "kb")
        self.assertNotIn(b + "usb-Razer_Razer_BlackWidow_V3-if02-event-mouse", got)
        self.assertEqual(got[b + "usb-Razer_Razer_DeathAdder_V2-event-mouse"], "mouse")
        self.assertEqual(got[b + "usb-Razer_Razer_DeathAdder_V2-if01-event-kbd"], "mouse")
        self.assertEqual(got[b + "usb-Razer_Razer_Basilisk-if01-event-kbd"], "mouse")
        self.assertNotIn(b + "usb-Razer_Razer_Kraken-event-joystick", got)
        self.assertNotIn(b + "usb-Logitech_USB_Receiver-event-mouse", got)

    def test_fallback_only_without_specific_nodes(self):
        import rgbmatrixfx.inputs as I
        d = tempfile.mkdtemp()
        for n in ("usb-Razer_Razer_Huntsman-event-kbd", "usb-Razer_Razer_Viper-event-mouse"):
            open(os.path.join(d, n), "w").close()
        hub = I.InputHub()
        self.assertTrue(hub.auto_kb and hub.auto_mouse)
        hub.generic_glob = os.path.join(d, "usb-Razer_*-event-*")
        hub.kb_globs = hub.mouse_globs = (os.path.join(d, "nothing-*"),)
        opened = []

        class FakeEvdev:
            class InputDevice:
                def __init__(self, path):
                    self.path, self.fd = path, 1000 + len(opened)
                    opened.append(path)
        hub.evdev = FakeEvdev
        I_set = I.set_rel_mask
        I.set_rel_mask = lambda fd: True
        try:
            hub.scan()
        finally:
            I.set_rel_mask = I_set
        kinds = sorted((os.path.basename(d_.path), k) for d_, k in hub.devs.values())
        self.assertEqual(kinds, [("usb-Razer_Razer_Huntsman-event-kbd", "kb"),
                                 ("usb-Razer_Razer_Viper-event-mouse", "mouse")])
        self.assertFalse(I.InputHub(kb_globs=("/x",)).auto_kb)


def _read(path, mode="r"):
    with open(path, mode) as f:
        return f.read()


class _Env:
    """temporarily point XDG_* at a scratch directory"""
    def __init__(self, **kw):
        self.kw, self.old = kw, {}

    def __enter__(self):
        for k, v in self.kw.items():
            self.old[k] = os.environ.get(k)
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        return self

    def __exit__(self, *a):
        for k, v in self.old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


class TestRenameAndMigration(unittest.TestCase):
    def test_identity(self):
        import rgbmatrixfx
        self.assertEqual((rgbmatrixfx.APP_ID, rgbmatrixfx.APP_NAME, rgbmatrixfx.LEGACY_APP_ID, rgbmatrixfx.PREVIOUS_APP_ID),
                         ("rgbmatrixfx", "RGBMatrixFX", "razer-fx", "razorfx"))
        self.assertEqual(rgbmatrixfx.LICENSE, "GPL-3.0-or-later WITH AdditionRef-RGBMatrixFX-plugin-exception")
        self.assertTrue(config.CONFIG_FILE.endswith(os.path.join("rgbmatrixfx", "config.json")))
        with _Env(XDG_RUNTIME_DIR="/run/user/4242"):
            self.assertEqual(ipc.socket_path(), "/run/user/4242/rgbmatrixfx/engine.sock")

    def test_migrates_1_0_config_once_and_leaves_it_alone(self):
        from rgbmatrixfx import migrate, paths
        d = tempfile.mkdtemp()
        with _Env(XDG_CONFIG_HOME=d):
            old = os.path.join(d, "razer-fx")
            os.makedirs(old)
            cfg = config.default_config()
            cfg["global"]["active_preset"] = "Razer Fire"
            cfg["presets"]["Trevor's"] = config.make_profile("wave")
            config.save(cfg, os.path.join(old, "config.json"))
            with open(os.path.join(old, "gui.ini"), "w") as f:
                f.write("[window]\nwidth=1500\n")
            open(os.path.join(old, ".config.abc.json"), "w").close()       # stray temp file
            before = {n: _read(os.path.join(old, n), "rb") for n in os.listdir(old)}
            self.assertEqual(migrate.migrate_config(), ["config.json", "gui.ini"])
            new = paths.config_dir()
            self.assertEqual(new, os.path.join(d, "rgbmatrixfx"))
            got = config.load(os.path.join(new, "config.json"))
            self.assertEqual(got["global"]["active_preset"], "Razer Fire")
            self.assertIn("Trevor's", got["presets"])
            self.assertTrue(os.path.exists(os.path.join(new, migrate.NOTE)))
            self.assertFalse(os.path.exists(os.path.join(new, ".config.abc.json")))
            self.assertEqual(before, {n: _read(os.path.join(old, n), "rb") for n in os.listdir(old)})
            # second run (or a 2nd process): nothing to do, and new edits are never overwritten
            got["global"]["active_preset"] = "Matrix"
            config.save(got, os.path.join(new, "config.json"))
            self.assertEqual(migrate.migrate_config(), [])
            self.assertEqual(config.load(os.path.join(new, "config.json"))["global"]["active_preset"], "Matrix")

    def test_migrates_razorfx_1_1_before_razer_fx(self):
        from rgbmatrixfx import migrate
        d = tempfile.mkdtemp()
        with _Env(XDG_CONFIG_HOME=d):
            for sub, preset in (("razer-fx", "Old 1.0"), ("razorfx", "Trevor 1.1")):
                os.makedirs(os.path.join(d, sub, "plugins"))
                cfg = config.default_config()
                cfg["global"]["active_preset"] = preset
                config.save(cfg, os.path.join(d, sub, "config.json"))
            open(os.path.join(d, "razorfx", "pro-test"), "w").close()
            with open(os.path.join(d, "razorfx", "plugins", "hello.json"), "w") as f:
                f.write("{}")
            got = migrate.migrate_config()
            self.assertEqual(sorted(got), ["config.json", os.path.join("plugins", "hello.json"), "pro-test"])
            new = os.path.join(d, "rgbmatrixfx")
            self.assertEqual(config.load(os.path.join(new, "config.json"))["global"]["active_preset"], "Trevor 1.1")
            self.assertTrue(os.path.exists(os.path.join(d, "razorfx", "config.json")))   # old dir untouched
            self.assertEqual(migrate.migrate_config(), [])

    def test_no_legacy_nothing_happens(self):
        from rgbmatrixfx import migrate
        d = tempfile.mkdtemp()
        with _Env(XDG_CONFIG_HOME=d):
            self.assertEqual(migrate.migrate_config(), [])
            self.assertEqual(os.listdir(d), [])

    def test_partial_new_dir_keeps_existing_files(self):
        from rgbmatrixfx import migrate
        d = tempfile.mkdtemp()
        with _Env(XDG_CONFIG_HOME=d):
            os.makedirs(os.path.join(d, "razer-fx"))
            os.makedirs(os.path.join(d, "rgbmatrixfx"))
            config.save(config.default_config(), os.path.join(d, "razer-fx", "config.json"))
            for sub, txt in (("razer-fx", "old"), ("rgbmatrixfx", "new")):
                with open(os.path.join(d, sub, "gui.ini"), "w") as f:
                    f.write(txt)
            self.assertEqual(migrate.migrate_config(), ["config.json"])
            self.assertEqual(_read(os.path.join(d, "rgbmatrixfx", "gui.ini")), "new")


class TestNoPyQt(unittest.TestCase):
    def test_sources_use_pyside6_only(self):
        import re
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        bad = []
        for dp, dn, fn in os.walk(root):
            dn[:] = [x for x in dn if x not in (".git", "__pycache__", "build", "dist")]
            for f in fn:
                if f.endswith(".py") or dp.endswith("bin"):
                    path = os.path.join(dp, f)
                    for i, line in enumerate(_read(path).splitlines(), 1):
                        if re.match(r"\s*(from|import)\s+(PyQt[56]|sip)\b", line) or re.search(r"\bpyqt(Signal|Slot|Property)\b", line):
                            bad.append("%s:%d: %s" % (os.path.relpath(path, root), i, line.strip()))
        self.assertEqual(bad, [])


class TestPluginApi(unittest.TestCase):
    class Host:
        capabilities = frozenset({"log", "settings", "storage", "events", "engine.status"})

        def __init__(self):
            self.lines = []

        def log(self, m):
            self.lines.append(m)

        def engine_status(self):
            return {"running": True, "effect": "wave"}

    def _plugin(self, base, pid, manifest=None, code="def register(ctx):\n    ctx.log('hi')\n", module=None):
        d = os.path.join(base, pid)
        os.makedirs(d, exist_ok=True)
        m = {"id": pid, "name": pid.title(), "version": "1.0", "api": "1.0"}
        m.update(manifest or {})
        import json
        with open(os.path.join(d, "plugin.json"), "w") as f:
            json.dump(m, f)
        if code is not None:
            with open(os.path.join(d, (module or m.get("module") or "plugin") + ".py"), "w") as f:
                f.write(code)
        return d

    def test_discover_load_and_isolate_failures(self):
        from rgbmatrixfx import plugin_api as api
        base, base2 = tempfile.mkdtemp(), tempfile.mkdtemp()
        self._plugin(base, "good", code="seen = []\ndef register(ctx):\n    ctx.log('hi')\n"
                     "    ctx.on('effect_changed', seen.append)\n    ctx.settings.set('n', 1)\n"
                     "def unregister():\n    seen.append('bye')\n")
        self._plugin(base, "newer", {"api": "1.9"})
        self._plugin(base, "major2", {"api": "2.0"})
        self._plugin(base, "noreg", code="x = 1\n")
        self._plugin(base, "crash", code="raise ImportError('nope')\n")
        self._plugin(base, "Bad Id")
        os.makedirs(os.path.join(base, "nomanifest"))
        os.makedirs(os.path.join(base, ".hidden"))
        self._plugin(base2, "good", code="def register(ctx):\n    raise SystemExit\n")   # duplicate: skipped
        d = tempfile.mkdtemp()
        with _Env(XDG_CONFIG_HOME=d, XDG_DATA_HOME=d):
            host = self.Host()
            pm = api.PluginManager(host, dirs=[base, base2])
            pm.load_all()
            self.assertEqual([p.info.id for p in pm.loaded], ["good"])
            why = {os.path.basename(p): r for p, r in pm.failed}
            self.assertEqual(set(why), {"newer", "major2", "noreg", "crash", "Bad Id", "nomanifest", "good"})
            self.assertIn("needs plugin API 2.0", why["major2"])
            self.assertIn("register", why["noreg"])
            self.assertIn("nope", why["crash"])
            self.assertIn("duplicate", why["good"])
            self.assertIn("plugin good: hi", host.lines)
            ctx = pm.loaded[0].ctx
            self.assertTrue(ctx.has("settings") and not ctx.has("gui.menu"))
            with self.assertRaises(api.PluginError):
                ctx.add_menu_action("x", lambda: None)
            self.assertEqual(ctx.engine_status()["effect"], "wave")
            self.assertTrue(os.path.isdir(ctx.data_dir) and ctx.data_dir.endswith("plugin-data/good"))
            pm.emit("effect_changed", "fire")
            mod = pm.loaded[0].module
            ctx.on("effect_changed", lambda e: 1 / 0)              # a failing handler is logged, not raised
            pm.emit("effect_changed", "wave")
            self.assertTrue(any("ZeroDivisionError" in l for l in host.lines))
            pm.unload_all()
            self.assertEqual(mod.seen, ["fire", "wave", "bye"])
            self.assertTrue(os.path.exists(os.path.join(d, "rgbmatrixfx", "plugins", "good.json")))

    def test_package_plugin_and_search_path(self):
        from rgbmatrixfx import plugin_api as api
        base = tempfile.mkdtemp()
        d = self._plugin(base, "pkg", {"module": "pkgmod"}, code=None)
        os.makedirs(os.path.join(d, "pkgmod"))
        with open(os.path.join(d, "pkgmod", "__init__.py"), "w") as f:
            f.write("from .helper import VALUE\ndef register(ctx):\n    ctx.log('value %d' % VALUE)\n")
        with open(os.path.join(d, "pkgmod", "helper.py"), "w") as f:
            f.write("VALUE = 42\n")
        with _Env(RGBMATRIXFX_PLUGIN_PATH=base, XDG_DATA_HOME="/nonexistent-data"):
            self.assertEqual(api.plugin_search_path(), [base, "/nonexistent-data/rgbmatrixfx/plugins"])
            host = self.Host()
            pm = api.PluginManager(host)
            pm.load_all()
        self.assertEqual([p.info.id for p in pm.loaded], ["pkg"])
        self.assertIn("plugin pkg: value 42", host.lines)

    def test_api_version_rules(self):
        from rgbmatrixfx.plugin_api import PluginInfo
        ok = lambda v: PluginInfo("/x", {"id": "a", "api": v}).api_compatible((1, 3))
        self.assertEqual([ok(v) for v in ("1", "1.0", "1.3", "1.4", "2.0", "0.9", "", "x")],
                         [True, True, True, False, False, False, False, False])

if __name__ == "__main__":
    unittest.main()


class TestAppearanceKde(unittest.TestCase):
    """KDE fallback (no portal): kdeglobals colours, and a live change of the file."""

    def test_kdeglobals(self):
        os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
        from PySide6.QtWidgets import QApplication
        app = QApplication.instance() or QApplication([])
        from rgbmatrixfx.gui.appearance import SystemAppearance
        with tempfile.TemporaryDirectory() as d, _Env(XDG_CONFIG_HOME=d, XDG_CURRENT_DESKTOP="KDE"):
            f = os.path.join(d, "kdeglobals")
            with open(f, "w") as fh:
                fh.write("[General]\nColorScheme=BreezeDark\nAccentColor=61,174,233\n\n"
                         "[Colors:Window]\nBackgroundNormal=32,35,38\n")
            sa = SystemAppearance(portal=False)
            self.assertEqual((sa.scheme, sa.accent, sa.scheme_source), ("dark", "#3daee9", "KDE"))
            seen = []
            sa.changed.connect(lambda: seen.append((sa.scheme, sa.accent)))
            tmp = f + ".new"                       # KDE rewrites the file atomically
            with open(tmp, "w") as fh:
                fh.write("[General]\nColorScheme=BreezeLight\nAccentColor=233,100,61\n\n"
                         "[Colors:Window]\nBackgroundNormal=239,240,241\n")
            os.replace(tmp, f)
            import time
            end = time.time() + 5
            while time.time() < end and not seen:
                app.processEvents()
                time.sleep(0.02)
            self.assertEqual(seen[-1:], [("light", "#e9643d")])

    def test_theme_colours(self):
        from rgbmatrixfx.gui import theme
        for scheme in theme.SCHEMES:
            for acc in ("#44d62c", "#ffff00", "#000000", "#3584e4"):
                d = theme.colors(scheme, acc)
                self.assertGreaterEqual(theme.contrast(d["ACCENT"], d["PANEL"]), 2.5, (scheme, acc))
                self.assertGreaterEqual(theme.contrast(d["TEXT"], d["BG"]), 7, scheme)
                self.assertGreaterEqual(theme.contrast(d["ON_ACCENT"], d["ACCENT"]), 2.4, (scheme, acc))
                self.assertNotIn("%(", theme.QSS % d)


class TestSdNotify(unittest.TestCase):
    def test_notify_socket(self):
        import socket
        from rgbmatrixfx import engine
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "notify")
            srv = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
            srv.bind(path)
            try:
                with _Env(NOTIFY_SOCKET=path):
                    self.assertTrue(engine.sd_notify("READY=1\nMAINPID=%d" % os.getpid()))
                self.assertEqual(srv.recv(200).decode(), "READY=1\nMAINPID=%d" % os.getpid())
            finally:
                srv.close()
        with _Env(NOTIFY_SOCKET=None):
            self.assertFalse(engine.sd_notify("READY=1"))


class TestDeviceMaps(unittest.TestCase):
    """devmaps: per-model keymaps from fake device specs (no hardware, no daemon needed)"""
    TABLES = {   # a cut-down copy of the shape of OpenRazer's tables (openrazer_daemon.keyboard)
        "KEY_MAPPING": {"ESC": (0, 1), "W": (2, 3), "A": (3, 2), "S": (3, 3), "D": (3, 4), "SPACE": (5, 7),
                        "LOGO": (0, 20), "NP5": (3, 19)},
        "EVENT_MAPPING": {1: "ESC", 17: "W", 30: "A", 31: "S", 32: "D", 57: "SPACE", 76: "NP5"},
        "TARTARUS_KEY_MAPPING": {"1": (0, 0), "2": (0, 1), "W": (1, 2)},
        "TARTARUS_EVENT_MAPPING": {15: "1", 16: "2", 17: "W"},
    }

    def spec(self, name, pid, rows, cols, kind="keyboard"):
        from rgbmatrixfx import devmaps
        return devmaps.DeviceSpec(kind, name, pid, rows, cols)

    def test_cynosa_uses_the_hand_tuned_map(self):
        from rgbmatrixfx import devmaps, layout as L
        km = devmaps.keyboard_keymap(self.spec("Razer Cynosa Chroma", 0x022A, 6, 22), self.TABLES)
        self.assertEqual(km.source, "hand-tuned")
        self.assertEqual(km.code_to_cell, L.KEYCODE_TO_CELL)
        self.assertEqual(km.cell_for_name("W"), (2, 3))
        self.assertEqual(km.logo, (0, 20))

    def test_standard_matrix_uses_openrazer_tables(self):
        from rgbmatrixfx import devmaps
        km = devmaps.keyboard_keymap(self.spec("Razer BlackWidow V3", 0x024E, 6, 22), self.TABLES)
        self.assertEqual(km.source, "OpenRazer keyboard map")
        self.assertEqual(km.code_to_cell[17], (2, 3))           # KEY_W
        self.assertEqual(km.code_to_cell[76], (3, 19))          # KEY_KP5
        self.assertEqual(km.cell_for_name("SPACE"), (5, 7))
        self.assertEqual(km.logo, (0, 20))
        self.assertNotIn(2, km.code_to_cell)                     # KEY_1 isn't in these tables

    def test_unknown_size_gets_a_generic_grid(self):
        from rgbmatrixfx import devmaps, layout as L
        for rows, cols in ((6, 16), (5, 15), (1, 1)):
            km = devmaps.keyboard_keymap(self.spec("Razer Blade", 0x0253, rows, cols), self.TABLES)
            self.assertTrue(km.source.startswith("generic grid"))
            self.assertEqual(len(km.cell_pos), rows * cols)
            for cell in km.code_to_cell.values():
                self.assertTrue(0 <= cell[0] < rows and 0 <= cell[1] < cols, cell)
            w, d = km.cell_for_name("W"), km.cell_for_name("D")
            self.assertTrue(w[1] <= d[1])                        # left-to-right order survives
            self.assertIsNone(km.logo)
        km = devmaps.keyboard_keymap(self.spec("Razer BlackWidow", 0x0221, 6, 22), None)   # no daemon tables
        self.assertTrue(km.source.startswith("generic grid"))

    def test_keypad_uses_the_tartarus_table(self):
        from rgbmatrixfx import devmaps
        km = devmaps.keyboard_keymap(self.spec("Razer Tartarus V2", 0x022B, 4, 6, "keypad"), self.TABLES)
        self.assertEqual(km.source, "OpenRazer Tartarus map")
        self.assertEqual(km.code_to_cell, {15: (0, 0), 16: (0, 1), 17: (1, 2)})

    def test_real_openrazer_tables_if_installed(self):
        from rgbmatrixfx import devmaps
        t = devmaps.openrazer_tables()
        if not t:
            self.skipTest("openrazer_daemon not importable here")
        km = devmaps.keyboard_keymap(self.spec("Razer Huntsman", 0x0227, 6, 22), t)
        self.assertEqual(km.cell_for_name("W"), (2, 3))
        self.assertEqual(km.cell_for_name("ESC"), (0, 1))

    def test_scene_compositor_with_other_devices(self):
        from rgbmatrixfx import devmaps, layout as L
        from rgbmatrixfx.scene import Scene, Compositor
        from rgbmatrixfx import config
        km = devmaps.keyboard_keymap(self.spec("Razer Blade", 0x0253, 6, 16), self.TABLES)
        sc = Scene(L.GENERIC_MOUSE, keymap=km, mouse_matrix=(1, 9), extras=[(1, 15), (1, 4)])
        self.assertEqual((sc.kb_rows, sc.kb_cols, sc.n_kb), (6, 16, 96))
        self.assertEqual(len(sc.mouse_points["logo"]), 9)              # strip around the outline
        self.assertEqual([len(c) for c in sc.extra_cells], [15, 4])
        self.assertTrue(sc.zone_present["extras"] and not sc.zone_present["kb_logo"])
        prof = config.make_profile("wave")
        comp = Compositor(sc, prof, dict(config.DEFAULT_GLOBAL, gamer_controls=True))
        rgb = comp.render(1.0)
        self.assertEqual(comp.kb_frame(rgb, 6, 16).shape, (6, 16, 3))
        mf = comp.mouse_frame(rgb, 1, 9)
        self.assertTrue(mf.any())
        xf = comp.extra_frames(rgb, [(1, 15), (1, 4)])
        self.assertEqual([f.shape for f in xf], [(1, 15, 3), (1, 4, 3)])
        self.assertTrue(all(f.any() for f in xf))
        w = sc.cell_index(*km.cell_for_name("W"))
        self.assertTrue((comp.render(1.1)[w] == 1.0).all())              # Gamer Controls on the grid
        self.assertTrue(comp.press_key(17, 1.2))                         # KEY_W ripples on this map


class TestLayoutPacks(unittest.TestCase):
    """user layout packs (docs/LAYOUTS.md): validation, loading, precedence"""
    HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    def pack(self, **kw):
        d = {"format": "rgbmatrixfx-layout", "version": 1, "name": "Test board", "kind": "keyboard",
             "match": {"usb": ["1532:022A"]}, "matrix": [6, 22], "keys": {"W": [0, 0], "KEY_A": [0, 1], "32": [0, 2]}}
        d.update(kw)
        return d

    def write(self, d, files):
        import json
        for name, data in files.items():
            with open(os.path.join(d, name), "w") as f:
                f.write(data if isinstance(data, str) else json.dumps(data))

    def test_example_layout_is_valid(self):
        import json
        from rgbmatrixfx import devmaps
        p = devmaps.validate_pack(json.load(open(os.path.join(self.HERE, "examples/layouts/example-layout.json"))))
        self.assertEqual(p["matrix"], (5, 15))
        self.assertEqual(p["keys"][17], (1, 2))                  # W

    def test_validation_errors(self):
        from rgbmatrixfx import devmaps
        for bad, why in ((dict(format="x"), "format"), (dict(version=2), "version"), (dict(matrix=[0, 5]), "matrix"),
                         (dict(match={}), "match"), (dict(keys={"NOPE": [0, 0]}), "unknown key"),
                         (dict(keys={"W": [6, 0]}), "outside"), (dict(keys={"W": "0,0"}), "row, col"),
                         (dict(kind="headset"), "kind"), (dict(kind="mouse", zones={"side": [[0, 0]]}), "zones")):
            with self.assertRaises(ValueError, msg=why) as cm:
                devmaps.validate_pack(self.pack(**bad))
            self.assertIn(why, str(cm.exception))

    def test_precedence_and_loading(self):
        import tempfile
        from rgbmatrixfx import devmaps
        cynosa = devmaps.DeviceSpec("keyboard", "Razer Cynosa Chroma", 0x022A, 6, 22)
        with tempfile.TemporaryDirectory() as d:
            self.write(d, {"b-broken.json": "{not json", "c-wrong.json": self.pack(matrix=[99, 1]),
                           "a-mine.json": self.pack(), "readme.txt": "ignored",
                           "d-second.json": self.pack(name="Second", keys={"W": [5, 5]})})
            logged = []
            packs = devmaps.load_packs([d], log=logged.append)
            self.assertEqual([p.name for p in packs], ["Test board", "Second"])
            self.assertEqual(len(logged), 2)                          # broken files are reported, skipped
            km = devmaps.keyboard_keymap(cynosa, TestDeviceMaps.TABLES, packs)
            self.assertTrue(km.source.startswith("layout pack \u201cTest board\u201d (a-mine.json)"), km.source)
            self.assertEqual(km.code_to_cell, {17: (0, 0), 30: (0, 1), 32: (0, 2)})   # 1) user pack beats hand-tuned
        self.assertEqual(devmaps.keyboard_keymap(cynosa, TestDeviceMaps.TABLES, []).source, "hand-tuned")   # 2)
        bw = devmaps.DeviceSpec("keyboard", "Razer BlackWidow", 0x0221, 6, 22)
        self.assertEqual(devmaps.keyboard_keymap(bw, TestDeviceMaps.TABLES, []).source, "OpenRazer keyboard map")  # 3)
        self.assertTrue(devmaps.keyboard_keymap(bw, None, []).source.startswith("generic grid"))           # 4)
        by_name = devmaps.LayoutPack(devmaps.validate_pack(self.pack(match={"name": ["blackwidow"]})))
        self.assertTrue(devmaps.keyboard_keymap(bw, TestDeviceMaps.TABLES, [by_name]).source.startswith("layout pack"))

    def test_mouse_pack_and_scene(self):
        from rgbmatrixfx import devmaps
        from rgbmatrixfx.scene import Scene, Compositor
        from rgbmatrixfx import config
        pk = devmaps.LayoutPack(devmaps.validate_pack(self.pack(kind="mouse", match={"usb": ["1532:0084"]}, matrix=[1, 3],
                                                                keys={}, zones={"logo": [[0, 2]], "scroll": [[0, 0]]})))
        spec = devmaps.DeviceSpec("mouse", "Razer DeathAdder V2", 0x0084, 1, 3)
        self.assertIs(devmaps.find_pack(spec, [pk]), pk)
        self.assertIsNone(devmaps.find_pack(spec._replace(kind="keyboard"), [pk]))
        prof = pk.mouse_profile()
        sc = Scene(prof, mouse_matrix=(1, 3))
        comp = Compositor(sc, config.make_profile("static", {"color": "#ff0000"}), dict(config.DEFAULT_GLOBAL))
        mf = comp.mouse_frame(comp.render(0.5), 1, 3)
        self.assertTrue(mf[0, 0].any() and mf[0, 2].any() and not mf[0, 1].any())

    def test_example_preset_imports_unchanged(self):
        import json
        from rgbmatrixfx import config
        d = json.load(open(os.path.join(self.HERE, "examples/presets/example-preset.json")))
        self.assertEqual(d["format"], "rgbmatrixfx-presets")
        profs = {k: v for k, v in d["presets"].items() if isinstance(v, dict)}
        self.assertEqual(list(profs), ["Example: Wave + WASD"])
        p = profs["Example: Wave + WASD"]
        clean = config.sanitize_profile(p)
        strip = lambda o: ({k: strip(v) for k, v in o.items() if not k.startswith("_")} if isinstance(o, dict)
                           else [strip(x) for x in o] if isinstance(o, list) else o)
        self.assertEqual(clean, strip(p))                       # every documented field round-trips
